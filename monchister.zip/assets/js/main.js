document.addEventListener('DOMContentLoaded', () => {
    var disclaimer = document.querySelector("img[alt='www.000webhost.com']");
    if(disclaimer) {
        disclaimer.remove();
    }
});